
public class listadoble {
	
		private String nombre;
		public asiento primera;
		public asiento  ultima;
}
